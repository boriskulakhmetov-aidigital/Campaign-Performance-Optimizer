
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.ts
import { verifyToken, createClerkClient } from "@clerk/backend";
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/functions/_shared/supabase.ts
import { createClient } from "@supabase/supabase-js";
var supabaseUrl = process.env.SUPABASE_URL || "https://njwzbptrhgznozpndcxf.supabase.co";
var supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
function getSupabase() {
  if (!supabaseKey) throw new Error("SUPABASE_SERVICE_ROLE_KEY not configured");
  return createClient(supabaseUrl, supabaseKey);
}
var supabase = new Proxy({}, {
  get(_, prop) {
    return getSupabase()[prop];
  }
});

// netlify/functions/_shared/logger.ts
import { createLogger } from "@boriskulakhmetov-aidigital/design-system/logger";
var log = createLogger(supabase, "campaign-optimizer");

// netlify/functions/_shared/auth.ts
async function requireAuth(req) {
  const secretKey = process.env.CLERK_SECRET_KEY;
  if (!secretKey) throw new Error("CLERK_SECRET_KEY not configured");
  const authHeader = req.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "").trim();
  if (!token) {
    log.warn("auth.failure", { function_name: "auth", message: "Unauthorized", meta: { endpoint: req.url } });
    throw new Error("Unauthorized");
  }
  const payload = await verifyToken(token, { secretKey });
  const userId = payload.sub;
  let email = null;
  try {
    const clerk = createClerkClient({ secretKey });
    const user = await clerk.users.getUser(userId);
    const primary = user.emailAddresses.find((e) => e.id === user.primaryEmailAddressId);
    email = primary?.emailAddress ?? null;
  } catch {
  }
  return { userId, email };
}

// netlify/functions/init-user.mts
var init_user_default = async (req, _context) => {
  try {
    const { userId, email } = await requireAuth(req);
    const { data, error } = await supabase.rpc("init_user", {
      p_user_id: userId,
      p_user_email: email ?? ""
    });
    if (error) {
      console.warn("[init-user] RPC error, falling back:", error.message);
      return Response.json({ status: "active", session_count: 0 });
    }
    return Response.json(data ?? { status: "active", session_count: 0 });
  } catch (err) {
    return Response.json({ status: "active", session_count: 0 }, { status: 200 });
  }
};
export {
  init_user_default as default
};
