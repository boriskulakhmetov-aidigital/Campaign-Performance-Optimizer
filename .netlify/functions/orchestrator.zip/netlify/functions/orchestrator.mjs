
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.ts
import { verifyToken, createClerkClient } from "@clerk/backend";
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/functions/_shared/supabase.ts
import { createClient } from "@supabase/supabase-js";
var supabaseUrl = process.env.SUPABASE_URL || "https://njwzbptrhgznozpndcxf.supabase.co";
var supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
function getSupabase() {
  if (!supabaseKey) throw new Error("SUPABASE_SERVICE_ROLE_KEY not configured");
  return createClient(supabaseUrl, supabaseKey);
}
var supabase = new Proxy({}, {
  get(_, prop) {
    return getSupabase()[prop];
  }
});
async function createSession(params) {
  const sb = getSupabase();
  await sb.from("cpo_sessions").upsert(
    {
      id: params.id,
      user_id: params.userId,
      user_email: params.userEmail ?? null,
      title: params.title ?? "Untitled Campaign",
      messages: [],
      status: "chatting",
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    },
    { onConflict: "id" }
  );
}
async function updateSession(id, payload) {
  const sb = getSupabase();
  await sb.from("cpo_sessions").update({ ...payload, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
}

// netlify/functions/_shared/logger.ts
import { createLogger } from "@boriskulakhmetov-aidigital/design-system/logger";
var log = createLogger(supabase, "campaign-optimizer");

// netlify/functions/_shared/auth.ts
async function requireAuth(req) {
  const secretKey = process.env.CLERK_SECRET_KEY;
  if (!secretKey) throw new Error("CLERK_SECRET_KEY not configured");
  const authHeader = req.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "").trim();
  if (!token) {
    log.warn("auth.failure", { function_name: "auth", message: "Unauthorized", meta: { endpoint: req.url } });
    throw new Error("Unauthorized");
  }
  const payload = await verifyToken(token, { secretKey });
  const userId = payload.sub;
  let email = null;
  try {
    const clerk = createClerkClient({ secretKey });
    const user = await clerk.users.getUser(userId);
    const primary = user.emailAddresses.find((e) => e.id === user.primaryEmailAddressId);
    email = primary?.emailAddress ?? null;
  } catch {
  }
  return { userId, email };
}

// netlify/functions/_shared/access.ts
import { checkAccess, recordUsage, getUserOrgId } from "@boriskulakhmetov-aidigital/design-system/access";
async function enforceAccess(userId, app) {
  return await checkAccess(supabase, userId, app);
}
async function trackUsage(userId, app) {
  const orgId = await getUserOrgId(supabase, userId);
  await recordUsage(supabase, userId, orgId, app);
}

// netlify/functions/orchestrator.mts
import { GoogleGenAI } from "@google/genai";
var ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
var APP_NAME = "campaign-optimizer";
var MODEL = "gemini-3-flash-preview";
var SYSTEM_PROMPT = `You are the Campaign Performance Optimizer \u2014 an expert AI media analyst for digital advertising campaigns.

Your job:
1. Help users ingest campaign performance data (CSV uploads or manual input)
2. Analyze campaign performance and identify underperforming ads
3. Dispatch analysis when you have enough data

## Conversation flow

### Phase 1: Data intake
When the user uploads a CSV or pastes campaign data:
- Acknowledge receipt and summarize what you see (campaigns, ad groups, total ads, date range if present)
- Confirm the platform (Google Ads, Meta, etc.) and campaign objective if not obvious
- Ask about vertical/industry and audience type if not clear

### Phase 2: Context gathering
Ask briefly about:
- Campaign objective (conversions, traffic, awareness, leads)
- Vertical/industry
- Audience type (prospecting, retargeting, lookalike, broad)
- Budget context (optional)
Do NOT ask all at once \u2014 fold naturally into conversation.

### Phase 3: Analysis dispatch
Once you have the campaign data AND context, emit an analysis_dispatch event.

When you are ready to dispatch, your FINAL assistant message must end with exactly this JSON block (no text after it):

\`\`\`json:analysis_dispatch
{
  "campaignName": "<campaign name>",
  "platform": "<google_search|google_display|google_pmax|meta|tiktok|linkedin|dv360|other>",
  "objective": "<conversions|traffic|awareness|leads>",
  "vertical": "<industry/vertical>",
  "audienceType": "<prospecting|retargeting|lookalike|broad>",
  "csvData": "<the full CSV text the user uploaded, exactly as received>"
}
\`\`\`

## Rules
- Be concise and professional. You are talking to a marketer, not a beginner.
- Use numbers and specifics. Avoid vague statements.
- If the user pastes raw data (not CSV), reformat it mentally and proceed.
- If the data is clearly incomplete (no metrics), say so and ask for the performance export.
- Never fabricate data or metrics.`;
var orchestrator_default = async (req, _context) => {
  try {
    const { userId, email } = await requireAuth(req);
    const access = await enforceAccess(userId, APP_NAME);
    if (!access.allowed) {
      return Response.json({ error: access.reason ?? "Access denied" }, { status: 403 });
    }
    const { messages, sessionId, csvText } = await req.json();
    log.info("orchestrator.start", {
      function_name: "orchestrator",
      user_id: userId,
      meta: { sessionId, messageCount: messages?.length }
    });
    if (sessionId) {
      await createSession({ id: sessionId, userId, userEmail: email ?? void 0 });
    }
    const contents = (messages || []).map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }]
    }));
    if (csvText && contents.length > 0) {
      const last = contents[contents.length - 1];
      if (last.role === "user") {
        last.parts[0].text = `[CSV Upload]
\`\`\`csv
${csvText}
\`\`\`

${last.parts[0].text}`;
      }
    }
    const stream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        function send(event, data) {
          controller.enqueue(encoder.encode(`event: ${event}
data: ${JSON.stringify(data)}

`));
        }
        try {
          const result = await ai.models.generateContentStream({
            model: MODEL,
            config: { systemInstruction: SYSTEM_PROMPT, temperature: 0.3 },
            contents
          });
          let fullText = "";
          for await (const chunk of result) {
            const text = chunk.text ?? "";
            if (text) {
              fullText += text;
              send("text_delta", { text });
            }
          }
          const dispatchMatch = fullText.match(/```json:analysis_dispatch\s*\n([\s\S]*?)\n```/);
          if (dispatchMatch) {
            try {
              const dispatchData = JSON.parse(dispatchMatch[1]);
              send("analysis_dispatch", { analysisConfig: dispatchData });
              if (sessionId) {
                await updateSession(sessionId, {
                  status: "analyzing",
                  intake_summary: dispatchData
                });
              }
            } catch {
            }
          }
          if (sessionId) {
            const allMessages = [
              ...messages || [],
              { role: "assistant", content: fullText }
            ];
            await updateSession(sessionId, {
              messages: allMessages.map((m) => ({
                role: m.role,
                content: m.content
              }))
            });
          }
          await trackUsage(userId, APP_NAME);
          send("done", {});
        } catch (err) {
          send("error", { message: err.message || "Streaming error" });
          log.error("orchestrator.stream_error", {
            function_name: "orchestrator",
            user_id: userId,
            message: err.message
          });
        } finally {
          controller.close();
        }
      }
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive"
      }
    });
  } catch (err) {
    log.error("orchestrator.error", {
      function_name: "orchestrator",
      message: err.message
    });
    return Response.json({ error: err.message }, { status: err.message === "Unauthorized" ? 401 : 500 });
  }
};
export {
  orchestrator_default as default
};
