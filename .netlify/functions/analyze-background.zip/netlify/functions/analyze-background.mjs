
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.ts
import { verifyToken, createClerkClient } from "@clerk/backend";
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/functions/_shared/supabase.ts
import { createClient } from "@supabase/supabase-js";
var supabaseUrl = process.env.SUPABASE_URL || "https://njwzbptrhgznozpndcxf.supabase.co";
var supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
function getSupabase() {
  if (!supabaseKey) throw new Error("SUPABASE_SERVICE_ROLE_KEY not configured");
  return createClient(supabaseUrl, supabaseKey);
}
var supabase = new Proxy({}, {
  get(_, prop) {
    return getSupabase()[prop];
  }
});
async function updateSession(id, payload) {
  const sb = getSupabase();
  await sb.from("cpo_sessions").update({ ...payload, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
}
async function writeJobStatus(jobId, payload) {
  const sb = getSupabase();
  await sb.from("job_status").upsert(
    {
      id: jobId,
      app: "campaign-optimizer",
      ...payload,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    },
    { onConflict: "id" }
  );
}

// netlify/functions/_shared/logger.ts
import { createLogger } from "@boriskulakhmetov-aidigital/design-system/logger";
var log = createLogger(supabase, "campaign-optimizer");

// netlify/functions/_shared/auth.ts
async function requireAuth(req) {
  const secretKey = process.env.CLERK_SECRET_KEY;
  if (!secretKey) throw new Error("CLERK_SECRET_KEY not configured");
  const authHeader = req.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "").trim();
  if (!token) {
    log.warn("auth.failure", { function_name: "auth", message: "Unauthorized", meta: { endpoint: req.url } });
    throw new Error("Unauthorized");
  }
  const payload = await verifyToken(token, { secretKey });
  const userId = payload.sub;
  let email = null;
  try {
    const clerk = createClerkClient({ secretKey });
    const user = await clerk.users.getUser(userId);
    const primary = user.emailAddresses.find((e) => e.id === user.primaryEmailAddressId);
    email = primary?.emailAddress ?? null;
  } catch {
  }
  return { userId, email };
}

// netlify/functions/analyze-background.mts
import { GoogleGenAI } from "@google/genai";
var ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
var MODEL = "gemini-3.1-pro-preview";
var ANALYSIS_PROMPT = `You are an expert media analyst. Analyze the following campaign data and produce a structured JSON report.

For each ad, compute a performance score (0-10) based on:
- CTR relative to platform benchmarks
- CPC efficiency
- Conversion rate
- ROAS (if revenue data available)

Flag ads as underperformers if score < 5.

Return ONLY valid JSON matching this schema:

{
  "campaign": {
    "name": "<name>",
    "platform": "<platform>",
    "objective": "<objective>",
    "vertical": "<vertical>",
    "audienceType": "<audience_type>"
  },
  "summary": {
    "totalAds": <int>,
    "totalImpressions": <int>,
    "totalClicks": <int>,
    "totalConversions": <int>,
    "totalSpend": <float>,
    "totalRevenue": <float>,
    "avgCtr": <float>,
    "avgCpc": <float>,
    "avgCvr": <float>,
    "avgRoas": <float>,
    "underperformerCount": <int>
  },
  "ads": [
    {
      "adGroup": "<ad group>",
      "adFormat": "rsa",
      "headline": "<primary headline>",
      "description": "<primary description>",
      "finalUrl": "<url>",
      "impressions": <int>,
      "clicks": <int>,
      "conversions": <int>,
      "spend": <float>,
      "revenue": <float>,
      "score": <float 0-10>,
      "scoreReasons": [
        {"metric": "ctr", "value": <float>, "benchmark": <float>, "verdict": "below|at|above"},
        {"metric": "cpc", "value": <float>, "benchmark": <float>, "verdict": "below|at|above"},
        {"metric": "cvr", "value": <float>, "benchmark": <float>, "verdict": "below|at|above"}
      ],
      "isUnderperformer": <bool>
    }
  ]
}

Platform benchmarks to use:
- Google Search: CTR 3.17%, CPC $2.69, CVR 3.75%
- Google Display: CTR 0.46%, CPC $0.63, CVR 0.77%
- Meta: CTR 0.90%, CPC $1.72, CVR 1.08%
- LinkedIn: CTR 0.65%, CPC $5.26, CVR 0.71%
- TikTok: CTR 1.02%, CPC $1.00, CVR 1.30%

Adjust benchmarks based on the vertical if you have domain knowledge.`;
var analyze_background_default = async (req, _context) => {
  const { userId } = await requireAuth(req);
  const { jobId, sessionId, analysisConfig } = await req.json();
  log.info("analyze.start", {
    function_name: "analyze-background",
    user_id: userId,
    entity_id: jobId,
    meta: { sessionId, platform: analysisConfig?.platform }
  });
  await writeJobStatus(jobId, {
    status: "streaming",
    phase: "analyzing",
    partial_text: "Analyzing campaign performance..."
  });
  try {
    const prompt = `${ANALYSIS_PROMPT}

Campaign context:
- Name: ${analysisConfig.campaignName}
- Platform: ${analysisConfig.platform}
- Objective: ${analysisConfig.objective}
- Vertical: ${analysisConfig.vertical}
- Audience: ${analysisConfig.audienceType}

CSV Data:
\`\`\`csv
${analysisConfig.csvData}
\`\`\``;
    const result = await ai.models.generateContent({
      model: MODEL,
      config: { temperature: 0.1, responseMimeType: "application/json" },
      contents: [{ role: "user", parts: [{ text: prompt }] }]
    });
    const text = result.text ?? "";
    let analysisData;
    try {
      analysisData = JSON.parse(text);
    } catch {
      const jsonMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
      if (jsonMatch) {
        analysisData = JSON.parse(jsonMatch[1]);
      } else {
        throw new Error("Failed to parse analysis response as JSON");
      }
    }
    const campaignData = analysisData.campaign || {};
    const { data: campaign } = await supabase.from("cpo_campaigns").insert({
      session_id: sessionId,
      user_id: userId,
      name: campaignData.name || analysisConfig.campaignName,
      platform: campaignData.platform || analysisConfig.platform,
      objective: campaignData.objective || analysisConfig.objective,
      vertical: campaignData.vertical || analysisConfig.vertical,
      audience_type: campaignData.audienceType || analysisConfig.audienceType,
      status: "analyzed"
    }).select("id").single();
    const campaignId = campaign?.id;
    if (campaignId && analysisData.ads?.length) {
      const adRows = analysisData.ads.map((ad) => ({
        campaign_id: campaignId,
        user_id: userId,
        ad_group: ad.adGroup || null,
        ad_format: ad.adFormat || "rsa",
        headline: ad.headline || null,
        description: ad.description || null,
        final_url: ad.finalUrl || null,
        impressions: ad.impressions || 0,
        clicks: ad.clicks || 0,
        conversions: ad.conversions || 0,
        spend: ad.spend || 0,
        revenue: ad.revenue || 0,
        score: ad.score ?? null,
        score_reasons: ad.scoreReasons || null,
        is_underperformer: ad.isUnderperformer ?? false
      }));
      await supabase.from("cpo_ads").insert(adRows);
    }
    await updateSession(sessionId, {
      status: "analyzed",
      report_data: analysisData
    });
    await writeJobStatus(jobId, {
      status: "complete",
      phase: "analyzed",
      partial_text: null
    });
    log.info("analyze.complete", {
      function_name: "analyze-background",
      user_id: userId,
      entity_id: jobId,
      meta: {
        totalAds: analysisData.ads?.length,
        underperformers: analysisData.summary?.underperformerCount
      }
    });
    return Response.json({ ok: true });
  } catch (err) {
    log.error("analyze.error", {
      function_name: "analyze-background",
      user_id: userId,
      entity_id: jobId,
      message: err.message
    });
    await writeJobStatus(jobId, {
      status: "error",
      phase: "analyze_failed",
      partial_text: err.message
    });
    return Response.json({ error: err.message }, { status: 500 });
  }
};
export {
  analyze_background_default as default
};
