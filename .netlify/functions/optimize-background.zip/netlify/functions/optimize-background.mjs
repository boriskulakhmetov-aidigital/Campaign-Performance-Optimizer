
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.ts
import { verifyToken, createClerkClient } from "@clerk/backend";
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/functions/_shared/supabase.ts
import { createClient } from "@supabase/supabase-js";
var supabaseUrl = process.env.SUPABASE_URL || "https://njwzbptrhgznozpndcxf.supabase.co";
var supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
function getSupabase() {
  if (!supabaseKey) throw new Error("SUPABASE_SERVICE_ROLE_KEY not configured");
  return createClient(supabaseUrl, supabaseKey);
}
var supabase = new Proxy({}, {
  get(_, prop) {
    return getSupabase()[prop];
  }
});
async function updateSession(id, payload) {
  const sb = getSupabase();
  await sb.from("cpo_sessions").update({ ...payload, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
}
async function writeJobStatus(jobId, payload) {
  const sb = getSupabase();
  await sb.from("job_status").upsert(
    {
      id: jobId,
      app: "campaign-optimizer",
      ...payload,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    },
    { onConflict: "id" }
  );
}

// netlify/functions/_shared/logger.ts
import { createLogger } from "@boriskulakhmetov-aidigital/design-system/logger";
var log = createLogger(supabase, "campaign-optimizer");

// netlify/functions/_shared/auth.ts
async function requireAuth(req) {
  const secretKey = process.env.CLERK_SECRET_KEY;
  if (!secretKey) throw new Error("CLERK_SECRET_KEY not configured");
  const authHeader = req.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "").trim();
  if (!token) {
    log.warn("auth.failure", { function_name: "auth", message: "Unauthorized", meta: { endpoint: req.url } });
    throw new Error("Unauthorized");
  }
  const payload = await verifyToken(token, { secretKey });
  const userId = payload.sub;
  let email = null;
  try {
    const clerk = createClerkClient({ secretKey });
    const user = await clerk.users.getUser(userId);
    const primary = user.emailAddresses.find((e) => e.id === user.primaryEmailAddressId);
    email = primary?.emailAddress ?? null;
  } catch {
  }
  return { userId, email };
}

// netlify/functions/optimize-background.mts
import { GoogleGenAI } from "@google/genai";
var ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
var MODEL = "gemini-3.1-pro-preview";
var OPTIMIZE_PROMPT = `You are an expert ad copywriter and campaign optimizer.

Given a list of underperforming ads, generate improved headline and description variations for each one.

For each variation:
1. Apply specific copywriting techniques (tag them precisely)
2. Explain your rationale briefly
3. Generate 2-3 variations per underperforming ad

Available technique tags:
- added_numbers: Include specific numbers/stats
- benefit_first: Lead with the outcome, not the feature
- urgency: Add time pressure or scarcity
- social_proof: Reference user counts, testimonials, awards
- question_hook: Open with an engaging question
- specificity: Replace vague claims with concrete details
- shorter: Reduce word count for punchier copy
- longer: Add detail where brevity lost clarity
- emotional: Use emotional language/triggers
- keyword_loaded: Include high-intent search keywords
- power_words: Use high-conversion words (free, proven, exclusive)
- negative_framing: Frame around loss aversion
- comparison: Position against alternatives

Return ONLY valid JSON:

{
  "variations": [
    {
      "adId": "<original ad id or index>",
      "adGroup": "<ad group for reference>",
      "originalHeadline": "<what we're improving>",
      "originalDescription": "<what we're improving>",
      "changeType": "headline|description|both",
      "headline": "<new headline or null>",
      "description": "<new description or null>",
      "techniques": ["technique_tag_1", "technique_tag_2"],
      "rationale": "<1-2 sentence explanation>"
    }
  ]
}`;
var optimize_background_default = async (req, _context) => {
  const { userId } = await requireAuth(req);
  const { jobId, sessionId, campaignId, analysisData } = await req.json();
  log.info("optimize.start", {
    function_name: "optimize-background",
    user_id: userId,
    entity_id: jobId,
    meta: { sessionId, campaignId }
  });
  await writeJobStatus(jobId, {
    status: "streaming",
    phase: "optimizing",
    partial_text: "Generating optimized ad variations..."
  });
  try {
    const underperformers = (analysisData.ads || []).filter((a) => a.isUnderperformer);
    if (underperformers.length === 0) {
      await writeJobStatus(jobId, {
        status: "complete",
        phase: "optimized",
        partial_text: null
      });
      return Response.json({ ok: true, message: "No underperformers to optimize" });
    }
    const prompt = `${OPTIMIZE_PROMPT}

Campaign context:
- Platform: ${analysisData.campaign?.platform || "google_search"}
- Objective: ${analysisData.campaign?.objective || "conversions"}
- Vertical: ${analysisData.campaign?.vertical || "unknown"}
- Audience: ${analysisData.campaign?.audienceType || "broad"}

Underperforming ads to optimize:
${JSON.stringify(underperformers, null, 2)}`;
    const result = await ai.models.generateContent({
      model: MODEL,
      config: { temperature: 0.7, responseMimeType: "application/json" },
      contents: [{ role: "user", parts: [{ text: prompt }] }]
    });
    const text = result.text ?? "";
    let optimizeData;
    try {
      optimizeData = JSON.parse(text);
    } catch {
      const jsonMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
      if (jsonMatch) {
        optimizeData = JSON.parse(jsonMatch[1]);
      } else {
        throw new Error("Failed to parse optimization response as JSON");
      }
    }
    const { data: dbAds } = await supabase.from("cpo_ads").select("id, ad_group, headline").eq("campaign_id", campaignId).eq("is_underperformer", true);
    if (optimizeData.variations?.length && campaignId) {
      const variationRows = optimizeData.variations.map((v) => {
        const matchedAd = dbAds?.find(
          (a) => a.ad_group === v.adGroup || a.headline === v.originalHeadline
        );
        return {
          ad_id: matchedAd?.id || dbAds?.[0]?.id,
          campaign_id: campaignId,
          user_id: userId,
          change_type: v.changeType || "both",
          headline: v.headline || null,
          description: v.description || null,
          techniques: v.techniques || [],
          rationale: v.rationale || null,
          status: "pending"
        };
      }).filter((r) => r.ad_id);
      if (variationRows.length) {
        await supabase.from("cpo_variations").insert(variationRows);
      }
    }
    const { data: currentSession } = await supabase.from("cpo_sessions").select("report_data").eq("id", sessionId).single();
    const updatedReportData = {
      ...currentSession?.report_data || {},
      variations: optimizeData.variations || [],
      summary: {
        ...currentSession?.report_data?.summary || {},
        variationsGenerated: optimizeData.variations?.length || 0
      }
    };
    await updateSession(sessionId, {
      status: "optimized",
      report_data: updatedReportData
    });
    await writeJobStatus(jobId, {
      status: "complete",
      phase: "optimized",
      partial_text: null
    });
    log.info("optimize.complete", {
      function_name: "optimize-background",
      user_id: userId,
      entity_id: jobId,
      meta: { variationsGenerated: optimizeData.variations?.length }
    });
    return Response.json({ ok: true });
  } catch (err) {
    log.error("optimize.error", {
      function_name: "optimize-background",
      user_id: userId,
      entity_id: jobId,
      message: err.message
    });
    await writeJobStatus(jobId, {
      status: "error",
      phase: "optimize_failed",
      partial_text: err.message
    });
    return Response.json({ error: err.message }, { status: 500 });
  }
};
export {
  optimize_background_default as default
};
