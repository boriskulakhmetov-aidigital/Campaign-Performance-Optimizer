
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/api-status.mts
import { createClient } from "@supabase/supabase-js";
import { handleApiStatus } from "@boriskulakhmetov-aidigital/design-system/server";
var APP_NAME = "campaign-optimizer";
function getSupabase() {
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
}
var api_status_default = async (req) => {
  return handleApiStatus(req, APP_NAME, getSupabase());
};
export {
  api_status_default as default
};
